package com.forgefx.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {
    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private WebView webView;
    private RewardedAd rewardedAd;
    private boolean loading = false;
    private boolean showing = false;
    private boolean earned = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff101722);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new RewardBridge(), "RewardBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
        new Thread(() -> { MobileAds.initialize(this, status -> {}); runOnUiThread(this::loadRewarded); }).start();
    }

    private void loadRewarded() {
        if (loading || rewardedAd != null || isFinishing()) return;
        loading = true;
        RewardedAd.load(this, TEST_REWARDED_ID, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { loading = false; rewardedAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError error) { loading = false; rewardedAd = null; }
        });
    }

    private void reply(boolean reward) {
        if (webView != null) webView.evaluateJavascript("window.onNativeRewarded(" + reward + ")", null);
    }

    private void showRewarded() {
        if (showing) return;
        if (rewardedAd == null) { loadRewarded(); reply(false); return; }
        RewardedAd ad = rewardedAd;
        rewardedAd = null;
        showing = true;
        earned = false;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                showing = false; reply(earned); loadRewarded();
            }
            @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError error) {
                showing = false; reply(false); loadRewarded();
            }
        });
        ad.show(this, reward -> earned = true);
    }

    public class RewardBridge {
        @JavascriptInterface public void showAd() { runOnUiThread(() -> showRewarded()); }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.history.back()", null);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() { if (webView != null) { webView.destroy(); webView = null; } super.onDestroy(); }
}
